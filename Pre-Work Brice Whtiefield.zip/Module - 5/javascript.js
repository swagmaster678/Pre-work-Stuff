<body>
<p1><b>Press the buttons to move the box!</b></p1>

<div id="box" style="height:150px; width:150px; background-color:blue; margin:25px"></div>

<button id="increase">grow</button>
<button id="decrease">shrink</button>
<button id="fadeaway">fade</button>
<button id="reset">reset</button>

<script>
function click() {
    document.getElementById("increase").addEventListener("click" , function()
        document.getElementById("box").style.height = "500px";
    )}
function click() {
    document.getElementById("decrease").addEventListener("click", function ()
        document.getElementById("box").style.height = "25px";
    )}
</script>
