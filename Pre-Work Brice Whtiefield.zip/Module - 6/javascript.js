$("#increase").on("click", function() {
    $("#box").animate({height:"+=250px", width:"+=250px"}, "fast");
})
$("#fadeaway").on("click", function() {
   $("#box").fadeOut()
})
$("#changecolor").on("click", function(){
console.log ("its running fine")
    $("#box").css("background-color", "blue")
})
$("#resetbutton").on("click", function(){
    $("#box").fadeIn()
    $("#box").css({"background-color": "orange", "width":"150px", "height":"150px"})
})
